package TEST;
public enum MenuCategory {
	DRINKS, MAINS, SIDES, DESSERTS;
}
